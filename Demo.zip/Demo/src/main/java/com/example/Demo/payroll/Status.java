package com.example.Demo.payroll;

public enum Status {
	IN_PROGRESS, 
	  COMPLETED, 
	  CANCELLED
}
